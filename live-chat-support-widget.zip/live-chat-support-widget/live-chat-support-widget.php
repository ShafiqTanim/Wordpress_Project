<?php
/*
Plugin Name: Live Chat Support Widget
Plugin URI: http://yourwebsite.com/
Description: A simple live chat support widget for WordPress.
Version: 1.0
Author: Your Name
Author URI: http://yourwebsite.com/
License: GPLv2 or later
*/

// Enqueue the necessary scripts and styles
function lcsw_enqueue_scripts() {
    wp_enqueue_style('lcsw-styles', plugin_dir_url(__FILE__) . 'assets/css/style.css');
    wp_enqueue_script('lcsw-scripts', plugin_dir_url(__FILE__) . 'assets/js/chat.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'lcsw_enqueue_scripts');

// Register the widget
function lcsw_register_widget() {
    register_widget('LCSW_Live_Chat_Widget');
}
add_action('widgets_init', 'lcsw_register_widget');

// Define the widget class
class LCSW_Live_Chat_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'lcsw_live_chat_widget',
            __('Live Chat Support Widget', 'lcsw'),
            array('description' => __('A widget to display live chat support.', 'lcsw'))
        );
    }

    public function widget($args, $instance) {
        echo $args['before_widget'];
        echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
        echo '<div id="lcsw-chat-box"></div>';  // Chat box container
        echo $args['after_widget'];
    }

    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : __('Live Chat Support', 'lcsw');
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_attr_e('Title:', 'lcsw'); ?></label> 
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <?php 
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
        return $instance;
    }
}
?>
